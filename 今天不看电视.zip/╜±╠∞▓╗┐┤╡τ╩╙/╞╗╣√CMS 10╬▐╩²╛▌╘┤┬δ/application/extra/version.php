<?php
return array (
    'name' => '苹果CMS',
    'copyright' => 'MacCMS.COM',
    'url' => 'http://www.maccms.com/',
    'code' => '2018.12.13.2151',
    'license' => '免费版',
);
?>