MacPlayer.Html = '<embed type="application/x-shockwave-flash" src="https://s.wasu.cn/portal/player/20180108/WsPlayer.swf" id="Player" bgcolor="#FFFFFF" quality="high" allowfullscreen="true" allowScriptAccess="always" flashvars="mode=3&vid='+ MacPlayer.PlayUrl +'&auto=1" pluginspage="http://www.macromedia.com/go/getflashplayer" width="100%" height="100%">';
MacPlayer.Show();


