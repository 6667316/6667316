**Typecho**

Typecho是一个简单轻巧的博客程序。基于 PHP 使用多种数据库（Mysql、PostgreSQL、SQLite）储存数据，在 GPL Version2 许可证下发行的开源程序，使用 SVN 做版本管理。

Typecho 是由两个单词 type 和 echo 组成的，在发音的时候也发这两个音 /taɪpˌ'ekoʊ/


**文档说明**

此文档根据typecho官方文档，进行微调整，修正了一部分过时的文档，同时增加了一些其他的文档，部分原创，部分摘抄自网络。

**提供**

此文档由<a href="http://qqdie.com" target="_blank">Jrotty</a> 提供，允许各种修改与传播。
